from Program.Config.Config import *
from Program.Config.Util import *

from Program.Config.Config import *
from Program.Config.Util import *

try:
   import webbrowser
   import re
   import pyzipper
   import msvcrt
   import time
   import os
   import sys
   import requests
   import colorama
   import datetime
   import json
   import zipfile
   import shutil
   import subprocess

   try:
      import winsound
   except:
      winsound = None

   from tkinter import messagebox

except Exception as e:
   ErrorModule(str(e))


def resource_path(relative_path):
   try:
      base_path = sys._MEIPASS
   except Exception:
      base_path = os.path.dirname(os.path.abspath(__file__))

   return os.path.join(base_path, relative_path)

option_01 = "Website-Vulnerability-Scanner"
option_02 = "Website-Info-Scanner"
option_03 = "Website-Url-Scanner"
option_04 = "Ip-Scanner"
option_05 = "Ip-Port-Scanner"
option_06 = "Ip-Pinger"
option_07 = "Soon"
option_08 = "Soon"
option_09 = "Soon"

option_10 = "D0x-Create"
option_11 = "D0x-Tracker"
option_12 = "Get-Image-Exif"
option_13 = "Google-Dorking"
option_14 = "Username-Tracker"
option_15 = "Email-Tracker"
option_16 = "Email-Lookup"
option_17 = "Phone-Number-Lookup"
option_18 = "Ip-Lookup"
option_19 = "Instagram-Account"

option_20 = "Phishing-Attack"
option_21 = "Password-Zip-Cracked-Attack"
option_22 = "Password-Hash-Decrypted-Attack"
option_23 = "Password-Hash-Encrypted"
option_24 = "Search-In-DataBase"
option_25 = "Dark-Web-Links"
option_26 = "Ip-Generator"
option_27 = "Soon"
option_28 = "Soon"
option_29 = "Soon"

option_30 = "Virus-Builder"

option_31 = "Python-Obfuscator-(Premium)"
option_32 = "Discord-Rat-(Premium)"
option_33 = "Website-DoS-(Premium)"
option_34 = "Proxy-Scraper-(Premium)"
option_35 = "Soon"
option_36 = "Soon"
option_37 = "Soon"
option_38 = "Soon"
option_39 = "Soon"

option_40 = "Roblox-Cookie-Login"
option_41 = "Roblox-Cookie-Info"
option_42 = "Roblox-Id-Info"
option_43 = "Roblox-User-Info"
option_44 = "Soon"
option_45 = "Soon"
option_46 = "Soon"
option_47 = "Soon"
option_48 = "Soon"
option_49 = "Soon"

option_50 = "Discord-Token-Nuker"
option_51 = "Discord-Token-Info"
option_52 = "Discord-Token-Joiner"
option_53 = "Discord-Token-Leaver"
option_54 = "Discord-Token-Login"
option_55 = "Discord-Token-To-Id-And-Brute"
option_56 = "Discord-Token-Server-Raid"
option_57 = "Discord-Token-Spammer"
option_58 = "Discord-Token-Delete-Friends"
option_59 = "Discord-Token-Block-Friends"
option_60 = "Discord-Token-Mass-Dm"
option_61 = "Discord-Token-Delete-Dm"
option_62 = "Discord-Token-Status-Changer"
option_63 = "Discord-Token-Language-Changer"
option_64 = "Discord-Token-House-Changer"
option_65 = "Discord-Token-Theme-Changer"
option_66 = "Discord-Token-Generator"
option_67 = "Discord-Bot-Server-Nuker"
option_68 = "Discord-Bot-Invite-To-Id"
option_69 = "Discord-Server-Info"
option_70 = "Discord-Nitro-Generator"
option_71 = "Discord-Webhook-Info"
option_72 = "Discord-Webhook-Delete"
option_73 = "Discord-Webhook-Spammer"
option_74 = "Discord-Webhook-Generator"
option_75 = "Soon"
option_76 = "Soon"
option_77 = "Soon"
option_78 = "Soon"
option_79 = "Soon"
option_80 = "Soon"

option_next = "Next"
option_back = "Back"
option_site = "Site"
option_info = "Info"

option_01_txt = f"{red}[{white}01{red}]{white} " + option_01.ljust(30)[:30].replace("-", " ")
option_02_txt = f"{red}[{white}02{red}]{white} " + option_02.ljust(30)[:30].replace("-", " ")
option_03_txt = f"{red}[{white}03{red}]{white} " + option_03.ljust(30)[:30].replace("-", " ")
option_04_txt = f"{red}[{white}04{red}]{white} " + option_04.ljust(30)[:30].replace("-", " ")
option_05_txt = f"{red}[{white}05{red}]{white} " + option_05.ljust(30)[:30].replace("-", " ")
option_06_txt = f"{red}[{white}06{red}]{white} " + option_06.ljust(30)[:30].replace("-", " ")
option_07_txt = f"{red}[{white}07{red}]{white} " + option_07.ljust(30)[:30].replace("-", " ")
option_08_txt = f"{red}[{white}08{red}]{white} " + option_08.ljust(30)[:30].replace("-", " ")
option_09_txt = f"{red}[{white}09{red}]{white} " + option_09.ljust(30)[:30].replace("-", " ")

option_10_txt = f"{red}[{white}10{red}]{white} " + option_10.ljust(30)[:30].replace("-", " ")
option_11_txt = f"{red}[{white}11{red}]{white} " + option_11.ljust(30)[:30].replace("-", " ")
option_12_txt = f"{red}[{white}12{red}]{white} " + option_12.ljust(30)[:30].replace("-", " ")
option_13_txt = f"{red}[{white}13{red}]{white} " + option_13.ljust(30)[:30].replace("-", " ")
option_14_txt = f"{red}[{white}14{red}]{white} " + option_14.ljust(30)[:30].replace("-", " ")
option_15_txt = f"{red}[{white}15{red}]{white} " + option_15.ljust(30)[:30].replace("-", " ")
option_16_txt = f"{red}[{white}16{red}]{white} " + option_16.ljust(30)[:30].replace("-", " ")
option_17_txt = f"{red}[{white}17{red}]{white} " + option_17.ljust(30)[:30].replace("-", " ")
option_18_txt = f"{red}[{white}18{red}]{white} " + option_18.ljust(30)[:30].replace("-", " ")
option_19_txt = f"{red}[{white}19{red}]{white} " + option_19.ljust(30)[:30].replace("-", " ")

option_20_txt = f"{red}[{white}20{red}]{white} " + option_20.ljust(30)[:30].replace("-", " ")
option_21_txt = f"{red}[{white}21{red}]{white} " + option_21.ljust(30)[:30].replace("-", " ")
option_22_txt = f"{red}[{white}22{red}]{white} " + option_22.ljust(30)[:30].replace("-", " ")
option_23_txt = f"{red}[{white}23{red}]{white} " + option_23.ljust(30)[:30].replace("-", " ")
option_24_txt = f"{red}[{white}24{red}]{white} " + option_24.ljust(30)[:30].replace("-", " ")
option_25_txt = f"{red}[{white}25{red}]{white} " + option_25.ljust(30)[:30].replace("-", " ")
option_26_txt = f"{red}[{white}26{red}]{white} " + option_26.ljust(30)[:30].replace("-", " ")
option_27_txt = f"{red}[{white}27{red}]{white} " + option_27.ljust(30)[:30].replace("-", " ")
option_28_txt = f"{red}[{white}28{red}]{white} " + option_28.ljust(30)[:30].replace("-", " ")
option_29_txt = f"{red}[{white}29{red}]{white} " + option_29.ljust(30)[:30].replace("-", " ")

option_30_txt = f"{red}[{white}30{red}]{white} " + option_30.ljust(30)[:30].replace("-", " ")
option_31_txt = f"{red}[{white}31{red}]{white} " + option_31.ljust(30)[:30].replace("-", " ")
option_32_txt = f"{red}[{white}32{red}]{white} " + option_32.ljust(30)[:30].replace("-", " ")
option_33_txt = f"{red}[{white}33{red}]{white} " + option_33.ljust(30)[:30].replace("-", " ")
option_34_txt = f"{red}[{white}34{red}]{white} " + option_34.ljust(30)[:30].replace("-", " ")
option_35_txt = f"{red}[{white}35{red}]{white} " + option_35.ljust(30)[:30].replace("-", " ")
option_36_txt = f"{red}[{white}36{red}]{white} " + option_36.ljust(30)[:30].replace("-", " ")
option_37_txt = f"{red}[{white}37{red}]{white} " + option_37.ljust(30)[:30].replace("-", " ")
option_38_txt = f"{red}[{white}38{red}]{white} " + option_38.ljust(30)[:30].replace("-", " ")
option_39_txt = f"{red}[{white}39{red}]{white} " + option_39.ljust(30)[:30].replace("-", " ")

option_40_txt = f"{red}[{white}40{red}]{white} " + option_40.ljust(30)[:30].replace("-", " ")
option_41_txt = f"{red}[{white}41{red}]{white} " + option_41.ljust(30)[:30].replace("-", " ")
option_42_txt = f"{red}[{white}42{red}]{white} " + option_42.ljust(30)[:30].replace("-", " ")
option_43_txt = f"{red}[{white}43{red}]{white} " + option_43.ljust(30)[:30].replace("-", " ")
option_44_txt = f"{red}[{white}44{red}]{white} " + option_44.ljust(30)[:30].replace("-", " ")
option_45_txt = f"{red}[{white}45{red}]{white} " + option_45.ljust(30)[:30].replace("-", " ")
option_46_txt = f"{red}[{white}46{red}]{white} " + option_46.ljust(30)[:30].replace("-", " ")
option_47_txt = f"{red}[{white}47{red}]{white} " + option_47.ljust(30)[:30].replace("-", " ")
option_48_txt = f"{red}[{white}48{red}]{white} " + option_48.ljust(30)[:30].replace("-", " ")
option_49_txt = f"{red}[{white}49{red}]{white} " + option_49.ljust(30)[:30].replace("-", " ")

option_50_txt = f"{red}[{white}50{red}]{white} " + option_50.ljust(30)[:30].replace("-", " ")
option_51_txt = f"{red}[{white}51{red}]{white} " + option_51.ljust(30)[:30].replace("-", " ")
option_52_txt = f"{red}[{white}52{red}]{white} " + option_52.ljust(30)[:30].replace("-", " ")
option_53_txt = f"{red}[{white}53{red}]{white} " + option_53.ljust(30)[:30].replace("-", " ")
option_54_txt = f"{red}[{white}54{red}]{white} " + option_54.ljust(30)[:30].replace("-", " ")
option_55_txt = f"{red}[{white}55{red}]{white} " + option_55.ljust(30)[:30].replace("-", " ")
option_56_txt = f"{red}[{white}56{red}]{white} " + option_56.ljust(30)[:30].replace("-", " ")
option_57_txt = f"{red}[{white}57{red}]{white} " + option_57.ljust(30)[:30].replace("-", " ")
option_58_txt = f"{red}[{white}58{red}]{white} " + option_58.ljust(30)[:30].replace("-", " ")
option_59_txt = f"{red}[{white}59{red}]{white} " + option_59.ljust(30)[:30].replace("-", " ")

option_60_txt = f"{red}[{white}60{red}]{white} " + option_60.ljust(30)[:30].replace("-", " ")
option_61_txt = f"{red}[{white}61{red}]{white} " + option_61.ljust(30)[:30].replace("-", " ")
option_62_txt = f"{red}[{white}62{red}]{white} " + option_62.ljust(30)[:30].replace("-", " ")
option_63_txt = f"{red}[{white}63{red}]{white} " + option_63.ljust(30)[:30].replace("-", " ")
option_64_txt = f"{red}[{white}64{red}]{white} " + option_64.ljust(30)[:30].replace("-", " ")
option_65_txt = f"{red}[{white}65{red}]{white} " + option_65.ljust(30)[:30].replace("-", " ")
option_66_txt = f"{red}[{white}66{red}]{white} " + option_66.ljust(30)[:30].replace("-", " ")
option_67_txt = f"{red}[{white}67{red}]{white} " + option_67.ljust(30)[:30].replace("-", " ")
option_68_txt = f"{red}[{white}68{red}]{white} " + option_68.ljust(30)[:30].replace("-", " ")
option_69_txt = f"{red}[{white}69{red}]{white} " + option_69.ljust(30)[:30].replace("-", " ")

option_70_txt = f"{red}[{white}70{red}]{white} " + option_70.ljust(30)[:30].replace("-", " ")
option_71_txt = f"{red}[{white}71{red}]{white} " + option_71.ljust(30)[:30].replace("-", " ")
option_72_txt = f"{red}[{white}72{red}]{white} " + option_72.ljust(30)[:30].replace("-", " ")
option_73_txt = f"{red}[{white}73{red}]{white} " + option_73.ljust(30)[:30].replace("-", " ")
option_74_txt = f"{red}[{white}74{red}]{white} " + option_74.ljust(30)[:30].replace("-", " ")
option_75_txt = f"{red}[{white}75{red}]{white} " + option_75.ljust(30)[:30].replace("-", " ")
option_76_txt = f"{red}[{white}76{red}]{white} " + option_76.ljust(30)[:30].replace("-", " ")
option_77_txt = f"{red}[{white}77{red}]{white} " + option_77.ljust(30)[:30].replace("-", " ")
option_78_txt = f"{red}[{white}78{red}]{white} " + option_78.ljust(30)[:30].replace("-", " ")
option_79_txt = f"{red}[{white}79{red}]{white} " + option_79.ljust(30)[:30].replace("-", " ")

option_back_txt = option_back + f" {red}[{white}B{red}]{white}"
option_next_txt = option_next + f" {red}[{white}N{red}]{white}"
option_site_txt = f"{red}[{white}S{red}]{white} " + option_site
option_info_txt =  f"{red}[{white}I{red}]{white} " + option_info

menu1 = f""" ┌─ {option_info_txt}                                                                                               {option_next_txt} ─┐
 ├─ {option_site_txt} ┌─────────────────┐                        ┌───────┐                           ┌───────────┐            │
 └─┬─────────┤ Network Scanner ├─────────┬──────────────┤ Osint ├──────────────┬────────────┤ Utilities ├────────────┴─
   │         └─────────────────┘         │              └───────┘              │            └───────────┘
   ├─ {option_01_txt                    }├─ {option_10_txt                    }├─ {option_20_txt}
   ├─ {option_02_txt                    }├─ {option_11_txt                    }├─ {option_21_txt}
   ├─ {option_03_txt                    }├─ {option_12_txt                    }├─ {option_22_txt}
   ├─ {option_04_txt                    }├─ {option_13_txt                    }├─ {option_23_txt}
   ├─ {option_05_txt                    }├─ {option_14_txt                    }├─ {option_24_txt}
   └─ {option_06_txt                    }├─ {option_15_txt                    }├─ {option_25_txt}
                                         ├─ {option_16_txt                    }└─ {option_26_txt}
                                         ├─ {option_17_txt                    }
                                         ├─ {option_18_txt                    }
                                         └─ {option_19_txt                    }

 ┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐
 │  [I] Info     [S] Site     [P] Profile     [T] Theme     [U] Update     [X] Exit              Next [N]  │
 └────────────────────────────────────────────── Discord ───────────────────────────────────────────────────┘
"""
menu2 = f""" ┌─ {option_info_txt}                                                                                                {option_next_txt} ─┐
 ├─ {option_site_txt}  ┌───────────────┐                         ┌──────┐                              ┌────────┐    {option_back_txt} ─┤
─┴─┬──────────┤ Virus Builder ├──────────┬──────────────┤ Paid ├───────────────┬──────────────┤ Roblox ├──────────────┴─
   │          └───────────────┘          │              └──────┘               │              └────────┘
   └─ {option_30_txt                    }├─ {option_31_txt                    }├─ {option_40_txt}
           ├─ Stealer                    ├─ {option_32_txt                    }├─ {option_41_txt}
           ├─ Grabber                    ├─ {option_33_txt                    }├─ {option_42_txt}
           └─ Malware                    └─ {option_34_txt                    }└─ {option_43_txt}

 ┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐
 │  [I] Info     [S] Site     [P] Profile     [T] Theme     [U] Update     [X] Exit     Back [B]   Next [N] │
 └────────────────────────────────────────────── Discord ───────────────────────────────────────────────────┘
"""

menu3 = f""" ┌─ {option_info_txt}                                                                                                {option_back_txt} ─┐
 ├─ {option_site_txt}                                           ┌─────────┐                                                    │
─┴─┬───────────────────────────────────────────────────┤ Discord ├────────────────────────────────────────────────────┘
   │                                                   └─────────┘                       
   ├─ {option_50_txt                    }┌─ {option_60_txt                    }┌─ {option_70_txt}
   ├─ {option_51_txt                    }├─ {option_61_txt                    }├─ {option_71_txt}
   ├─ {option_52_txt                    }├─ {option_62_txt                    }├─ {option_72_txt}
   ├─ {option_53_txt                    }├─ {option_63_txt                    }├─ {option_73_txt}
   ├─ {option_54_txt                    }├─ {option_64_txt                    }├─ {option_74_txt}
   ├─ {option_55_txt                    }├─ {option_65_txt                    }│
   ├─ {option_56_txt                    }├─ {option_66_txt                    }│
   ├─ {option_57_txt                    }├─ {option_67_txt                    }│
   ├─ {option_58_txt                    }├─ {option_68_txt                    }│
   ├─ {option_59_txt                    }├─ {option_69_txt                    }│
   └─────────────────────────────────────┴─────────────────────────────────────┘

 ┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐
 │  [I] Info     [S] Site     [P] Profile     [T] Theme     [U] Update     [X] Exit              Back [B]  │
 └────────────────────────────────────────────── Discord ───────────────────────────────────────────────────┘
"""

def Update():
   popup_version = ""
   try:
      new_version = re.search(r'version_tool\s*=\s*"([^"]+)"', requests.get(url_config).text).group(1)
      if new_version != version_tool:
         webbrowser.open(f"https://{github_tool}")
         colorama.init()
         input(f"{BEFORE + current_time_hour() + AFTER} {INFO} Please install the new version of the tool: {white + version_tool + red} -> {white + new_version} ")
         popup_version = f"{red}New Version: {white + version_tool + red} -> {white + new_version}"
         colorama.deinit()
         Clear()
   except: pass

   return popup_version

appdata_path = os.path.join(os.getenv("APPDATA"), "ParableTool")
os.makedirs(appdata_path, exist_ok=True)

menu_path = os.path.join(appdata_path, "Menu.txt")

if not os.path.exists(menu_path):
   with open(menu_path, "w") as file:
      file.write("1")


def Menu():
   popup_version = ""

   try:
      with open(menu_path, "r") as file:
         menu_number = file.read().strip()

      menu_mapping = {"1": menu1, "2": menu2, "3": menu3}
      menu = menu_mapping.get(menu_number, menu1)

   except:
      menu = menu1
      menu_number = "1"

   banner = BuildBanner(menu, 999)

   return banner, menu_number, menu



menu_path = os.path.join(appdata_path, "Menu.txt")

if not os.path.exists(menu_path):
   with open(menu_path, "w") as file:
      file.write("1")

BLACK = "\033[38;5;16m"
DARK_GRAY = "\033[38;5;236m"
GRAY = "\033[38;5;245m"
WHITE = "\033[97m"
RED = "\033[38;5;196m"
RED2 = "\033[38;5;160m"
RED3 = "\033[38;5;88m"
GREEN = "\033[38;5;46m"
YELLOW = "\033[38;5;226m"
CYAN = "\033[38;5;51m"
UI_WIDTH = 62


# ==========================================================
# ⚙️ PARABLE SETTINGS / THEMES / PROFILE
# ==========================================================

# ==========================================================
# 🎨 PARABLE PROFESSIONAL THEME ENGINE
# Colores disponibles: Red, Blue, Purple, Green, Gold, White
# Este bloque reemplaza el sistema viejo de colores para que
# la paleta cambie el logo, menús, auth, profile, update, etc.
# ==========================================================

RESET = "\033[0m"

BLACK = "\033[38;5;16m"
DARK_GRAY = "\033[38;5;236m"
GRAY = "\033[38;5;245m"
WHITE = "\033[97m"
RED = "\033[38;5;196m"
RED2 = "\033[38;5;203m"
RED3 = "\033[38;5;88m"
GREEN = "\033[38;5;46m"
YELLOW = "\033[38;5;226m"
CYAN = "\033[38;5;51m"

reset = RESET
red = RED
white = WHITE
green = GREEN
yellow = YELLOW

UI_WIDTH = 62
SETTINGS_PATH = "settings.json"
PROFILE_PATH = "parable_profile.json"

THEMES = {
   "1": {
      "name": "Red",
      "primary": "\033[38;5;196m",
      "secondary": "\033[38;5;88m",
      "accent": "\033[38;5;203m",
      "success": "\033[38;5;46m",
      "warning": "\033[38;5;226m",
      "text": "\033[97m",
      "muted": "\033[38;5;245m",
      "cyan": "\033[38;5;51m"
   },
   "2": {
      "name": "Blue",
      "primary": "\033[38;5;39m",
      "secondary": "\033[38;5;24m",
      "accent": "\033[38;5;51m",
      "success": "\033[38;5;46m",
      "warning": "\033[38;5;226m",
      "text": "\033[97m",
      "muted": "\033[38;5;245m",
      "cyan": "\033[38;5;51m"
   },
   "3": {
      "name": "Purple",
      "primary": "\033[38;5;135m",
      "secondary": "\033[38;5;55m",
      "accent": "\033[38;5;201m",
      "success": "\033[38;5;46m",
      "warning": "\033[38;5;226m",
      "text": "\033[97m",
      "muted": "\033[38;5;245m",
      "cyan": "\033[38;5;51m"
   },
   "4": {
      "name": "Green",
      "primary": "\033[38;5;46m",
      "secondary": "\033[38;5;22m",
      "accent": "\033[38;5;82m",
      "success": "\033[38;5;46m",
      "warning": "\033[38;5;226m",
      "text": "\033[97m",
      "muted": "\033[38;5;245m",
      "cyan": "\033[38;5;51m"
   },
   "5": {
      "name": "Gold",
      "primary": "\033[38;5;220m",
      "secondary": "\033[38;5;94m",
      "accent": "\033[38;5;226m",
      "success": "\033[38;5;46m",
      "warning": "\033[38;5;214m",
      "text": "\033[97m",
      "muted": "\033[38;5;245m",
      "cyan": "\033[38;5;51m"
   },
   "6": {
      "name": "White",
      "primary": "\033[97m",
      "secondary": "\033[38;5;245m",
      "accent": "\033[38;5;255m",
      "success": "\033[38;5;46m",
      "warning": "\033[38;5;226m",
      "text": "\033[97m",
      "muted": "\033[38;5;245m",
      "cyan": "\033[38;5;51m"
   }
}

# Códigos antiguos que podían quedar pegados dentro de strings ya creados.
# Esto permite que el menú cambie de color aunque menu1/menu2/menu3 ya tengan ANSI viejo.
KNOWN_THEME_ANSI = [
   "\033[38;5;196m", "\033[38;5;88m", "\033[38;5;203m",
   "\033[38;5;39m", "\033[38;5;24m", "\033[38;5;51m",
   "\033[38;5;135m", "\033[38;5;55m", "\033[38;5;201m",
   "\033[38;5;46m", "\033[38;5;22m", "\033[38;5;82m",
   "\033[38;5;220m", "\033[38;5;94m", "\033[38;5;226m",
   "\033[38;5;160m"
]


def LoadSettings():
   default = {
      "theme": "1",
      "animations": True,
      "sound": True,
      "auto_update": True,
      "language": "English"
   }

   try:
      if not os.path.exists(SETTINGS_PATH):
         with open(SETTINGS_PATH, "w", encoding="utf-8") as file:
            json.dump(default, file, indent=4)
         return default

      with open(SETTINGS_PATH, "r", encoding="utf-8") as file:
         data = json.load(file)

      for key, value in default.items():
         if key not in data:
            data[key] = value

      if str(data.get("theme", "1")) not in THEMES:
         data["theme"] = "1"

      return data

   except:
      return default


def SaveSettings(settings):
   try:
      with open(SETTINGS_PATH, "w", encoding="utf-8") as file:
         json.dump(settings, file, indent=4)
      return True
   except:
      return False


SETTINGS = LoadSettings()


def ApplyTheme():
   global RESET, BLACK, DARK_GRAY, GRAY, WHITE, RED, RED2, RED3, GREEN, YELLOW, CYAN
   global reset, red, white, green, yellow

   theme_id = str(SETTINGS.get("theme", "1"))
   theme = THEMES.get(theme_id, THEMES["1"])

   RESET = "\033[0m"
   BLACK = "\033[38;5;16m"
   DARK_GRAY = "\033[38;5;236m"
   GRAY = theme["muted"]
   WHITE = theme["text"]
   RED = theme["primary"]
   RED2 = theme["accent"]
   RED3 = theme["secondary"]
   GREEN = theme["success"]
   YELLOW = theme["warning"]
   CYAN = theme["cyan"]

   reset = RESET
   red = RED
   white = WHITE
   green = GREEN
   yellow = YELLOW


def ReThemeText(text):
   try:
      text = str(text)

      # Cambia colores antiguos por el color principal actual.
      for ansi in KNOWN_THEME_ANSI:
         text = text.replace(ansi, RED)

      # Mantiene blanco/reset correctamente.
      text = text.replace("\033[97m", WHITE)
      text = text.replace("\033[0m", RESET)

      return text
   except:
      return str(text)


def MainColor(text):
   try:
      return f"{RED}{ReThemeText(text)}{RESET}"
   except:
      return str(text)


ApplyTheme()


def SafeClear():
   try:
      Clear()
   except:
      os.system("cls" if os.name == "nt" else "clear")


def SafeTitle(title):
   try:
      Title(title)
   except:
      if os.name == "nt":
         os.system(f"title {title}")


def SaveProfile(username, license_time="Unknown", status="Active"):
   try:
      old = {}
      if os.path.exists(PROFILE_PATH):
         try:
            with open(PROFILE_PATH, "r", encoding="utf-8") as file:
               old = json.load(file)
         except:
            old = {}

      data = {
         "username": username,
         "license": license_time,
         "status": status,
         "hwid": "Verified",
         "access": "Premium",
         "theme": THEMES.get(str(SETTINGS.get("theme", "1")), THEMES["1"])["name"],
         "created_at": old.get("created_at", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")),
         "last_login": datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
      }

      with open(PROFILE_PATH, "w", encoding="utf-8") as file:
         json.dump(data, file, indent=4)

      return True
   except:
      return False


def LoadProfile():
   try:
      if not os.path.exists(PROFILE_PATH):
         return None

      with open(PROFILE_PATH, "r", encoding="utf-8") as file:
         return json.load(file)
   except:
      return None


def ShowProfilePanel():
   profile = LoadProfile()

   if not profile:
      profile = {
         "username": "Unknown",
         "license": "Unknown",
         "status": "Not saved",
         "hwid": "Unknown",
         "access": "Unknown",
         "theme": THEMES.get(str(SETTINGS.get("theme", "1")), THEMES["1"])["name"],
         "created_at": "Unknown",
         "last_login": "Unknown"
      }

   SafeClear()
   SafeTitle("Parable Profile")

   print("")
   try:
      print(ShineLogo(999), end="")
   except:
      pass

   print(f"{RED}                                           User Profile Panel{RESET}")
   print("")
   print(f"{RED} ┌────────────────────────────────────────────────────────┐{RESET}")
   print(f"{RED} │{WHITE}                    PARABLE PROFILE                    {RED}│{RESET}")
   print(f"{RED} ├────────────────────────────────────────────────────────┤{RESET}")
   print(f"{RED} │{WHITE} Username   : {RED}{str(profile.get('username', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} License    : {WHITE}{str(profile.get('license', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Status     : {GREEN}{str(profile.get('status', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} HWID       : {GREEN}{str(profile.get('hwid', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Access     : {WHITE}{str(profile.get('access', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Theme      : {RED}{str(profile.get('theme', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Created    : {WHITE}{str(profile.get('created_at', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Last Login : {WHITE}{str(profile.get('last_login', 'Unknown')).ljust(37)}{RED}│{RESET}")
   print(f"{RED} └────────────────────────────────────────────────────────┘{RESET}")
   print("")
   input(f"{RED} [{WHITE}!{RED}]{WHITE} Press Enter to return... {RESET}")


def ThemePreview(theme_id):
   theme = THEMES.get(theme_id, THEMES["1"])
   p = theme["primary"]
   a = theme["accent"]
   sec = theme["secondary"]
   s = theme["success"]
   w = theme["text"]
   r = "\033[0m"

   print(f"   {p}┌──────────────────────────────┐{r}")
   print(f"   {p}│{w} Theme: {a}{theme['name'].ljust(20)}{p}│{r}")
   print(f"   {p}│{w} Primary {p}███{w} Accent {a}███{p} │{r}")
   print(f"   {p}│{w} Deep    {sec}███{w} Status {s}OK {p} │{r}")
   print(f"   {p}└──────────────────────────────┘{r}")


def ThemePanel():
   while True:
      SafeClear()
      SafeTitle("Parable Theme Panel")

      print("")
      try:
         print(ShineLogo(999), end="")
      except:
         pass

      current_theme = str(SETTINGS.get("theme", "1"))
      current_name = THEMES.get(current_theme, THEMES["1"])["name"]

      print(f"{RED}                                           Color Customization Panel{RESET}")
      print("")
      print(f"{RED} ┌────────────────────────────────────────────────────────┐{RESET}")
      print(f"{RED} │{WHITE}                 PARABLE THEME PANEL                  {RED}│{RESET}")
      print(f"{RED} ├────────────────────────────────────────────────────────┤{RESET}")
      print(f"{RED} │{WHITE} Current Theme: {RED}{current_name.ljust(38)}{RED}│{RESET}")
      print(f"{RED} │{GRAY} Select a color theme and it will be saved.            {RED}│{RESET}")
      print(f"{RED} └────────────────────────────────────────────────────────┘{RESET}")
      print("")

      for theme_id, theme in THEMES.items():
         marker = ">" if theme_id == current_theme else " "
         print(f" {theme['primary']}[{theme['text']}{theme_id}{theme['primary']}] {theme['text']}{marker} {theme['name']}{RESET}")

      print("")
      ThemePreview(current_theme)
      print("")
      print(f"{RED} [{WHITE}1-6{RED}]{WHITE} Change theme")
      print(f"{RED} [{WHITE}B{RED}]{WHITE} Back to menu")
      print("")

      choice = input(f"{RED} └─{WHITE}$ {RESET}").strip().lower()

      if choice in THEMES:
         SETTINGS["theme"] = choice
         SaveSettings(SETTINGS)
         ApplyTheme()

         profile = LoadProfile()
         if profile:
            SaveProfile(profile.get("username", "Unknown"), profile.get("license", "Unknown"), profile.get("status", "Active"))

         SafeClear()
         SafeTitle("Theme Applied")
         print("")
         print(f"{RED} ┌──────────────────────────────────────────────┐{RESET}")
         print(f"{RED} │{WHITE}              THEME APPLIED             {RED}│{RESET}")
         print(f"{RED} └──────────────────────────────────────────────┘{RESET}")
         print("")
         try:
            SlowPrint(f"{RESET} {RED}[{WHITE}+{RED}]{WHITE} New theme: {RED}{THEMES[choice]['name']}{RESET}", 0.02)
         except:
            print(f"{RESET} {RED}[{WHITE}+{RED}]{WHITE} New theme: {RED}{THEMES[choice]['name']}{RESET}")
         time.sleep(1)

      elif choice in ["b", "back", "exit"]:
         return

      else:
         print(f"{RED} [{WHITE}x{RED}]{WHITE} Invalid option.{RESET}")
         time.sleep(0.8)




def EnableAnsi():
   try:
      if os.name == "nt":
         os.system("")
         import ctypes
         kernel32 = ctypes.windll.kernel32
         handle = kernel32.GetStdHandle(-11)
         mode = ctypes.c_ulong()
         kernel32.GetConsoleMode(handle, ctypes.byref(mode))
         mode.value |= 0x0004
         kernel32.SetConsoleMode(handle, mode)
   except:
      pass


def SetProfessionalConsole(cols=150, lines=42):
   try:
      if os.name == "nt":
         os.system(f"mode con: cols={cols} lines={lines}")
         try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            class COORD(ctypes.Structure):
               _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]
            kernel32.SetConsoleScreenBufferSize(handle, COORD(cols, lines))
         except:
            pass
   except:
      pass


def HideCursor():
   print("\033[?25l", end="", flush=True)


def ShowCursor():
   print("\033[?25h", end="", flush=True)


def Center(text, width=UI_WIDTH):
   return str(text).center(width)


def SlowPrint(text, delay=0.012):
   for char in str(text):
      print(char, end="", flush=True)
      time.sleep(delay)
   print()


def Box(title, lines=None, width=UI_WIDTH):
   if lines is None:
      lines = []
   print(f"{RED} ┌" + "─" * width + f"┐{RESET}")
   print(f"{RED} │{WHITE}" + Center(title, width) + f"{RED}│{RESET}")
   print(f"{RED} ├" + "─" * width + f"┤{RESET}")
   for line in lines:
      clean = str(line)
      if len(clean) > width:
         clean = clean[:width - 3] + "..."
      print(f"{RED} │{WHITE}" + clean.ljust(width) + f"{RED}│{RESET}")
   print(f"{RED} └" + "─" * width + f"┘{RESET}")


def LoadingBar(text="Loading", seconds=1.2, width=32):
   frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
   steps = max(1, int(seconds / 0.04))
   for i in range(steps + 1):
      percent = int((i / steps) * 100)
      filled = int((percent / 100) * width)
      bar = "█" * filled + "░" * (width - filled)
      frame = frames[i % len(frames)]
      print(MainColor(f"\r {red}[{white}{frame}{red}]{white} {text} {red}[{white}{bar}{red}]{white} {percent}%"), end="", flush=True)
      time.sleep(0.04)
   print("\r" + " " * 120 + "\r", end="", flush=True)


def StatusOK(text):
   print(MainColor(f" {red}[{white}+{red}]{white} {text} ") + GREEN + "OK" + RESET)


def StatusError(text):
   print(MainColor(f" {red}[x]{white} {text}"))


def PressToContinue():
   input(MainColor(f"\n {red}[!]{white} Press Enter to continue...{reset}"))


def PageTransition(title="Loading"):
   HideCursor()
   try:
      for i in range(8):
         Clear()
         Title(title)
         print("")
         print("")
         print(ShineLogo(i * 7), end="")
         print(MainColor("                                           discord.gg/JdRaaAedut"))
         print("")
         LoadingBar("Rendering interface", 0.18, 24)
   finally:
      ShowCursor()

PARABLE_LOGO = [
   "██████╗  █████╗ ██████╗  █████╗ ██████╗ ██╗     ███████╗",
   "██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔══██╗██║     ██╔════╝",
   "██████╔╝███████║██████╔╝███████║██████╔╝██║     █████╗  ",
   "██╔═══╝ ██╔══██║██╔══██╗██╔══██║██╔══██╗██║     ██╔══╝  ",
   "██║     ██║  ██║██║  ██║██║  ██║██████╔╝███████╗███████╗",
   "╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝"
]


def ShineLogo(shine_pos):
   result = ""

   for line in PARABLE_LOGO:
      padding = " " * 28
      colored_line = ""

      for i, char in enumerate(line):
         distance = abs(i - shine_pos)

         if distance == 0:
            color = WHITE
         elif distance == 1:
            color = RED2
         elif distance == 2:
            color = RED
         else:
            color = RED3

         colored_line += color + char

      result += padding + colored_line + RESET + "\n"

   return result



def BuildBanner(menu, shine_pos):
   return f"""                                                                                      
{ShineLogo(shine_pos)}
{RED}                                           discord.gg/JdRaaAedut{RESET}
{ReThemeText(menu)}"""


def AnimateLogo(menu, menu_number):
   logo_width = len(PARABLE_LOGO[0])
   shine_pos = -6
   buffer = ""
   menu_lines = menu.splitlines()
   total_lines = len(menu_lines)
   visible_lines = 0
   HideCursor()
   try:
      while True:
         Clear()
         Title(f"Parable Tool | Menu {menu_number}")
         print("")
         print("")
         print(ShineLogo(shine_pos), end="")
         print(MainColor("                                           discord.gg/JdRaaAedut"))
         print(MainColor("                                           "))
         print("")
         for line in menu_lines[:visible_lines]:
            print(MainColor(ReThemeText(line)))
         print(f"{RED} ┌──({WHITE}{username_pc}{RED}@{WHITE}parable{RED})─[{WHITE}~/{os_name}/Menu-{menu_number}{RED}]{RESET}")
         print(f"{RED} └─{WHITE}$ {RESET}{buffer}", end="", flush=True)
         shine_pos += 1
         if shine_pos > logo_width + 6:
            shine_pos = -6
         if visible_lines < total_lines:
            visible_lines += 1
         start_time = time.time()
         while time.time() - start_time < 0.055:
            if msvcrt.kbhit():
               key = msvcrt.getwch()
               if key == "\r":
                  ShowCursor()
                  return buffer.strip()
               elif key == "\b":
                  buffer = buffer[:-1]
               else:
                  if key.lower() in ["b", "n", "i", "s", "p", "t", "u", "x"]:
                     ShowCursor()
                     return key
                  buffer += key
            time.sleep(0.001)
   finally:
      ShowCursor()



KEYAUTH_NAME = "Parable-Tool"
KEYAUTH_OWNERID = "zop16VhaIU"
KEYAUTH_VERSION = "1.0"
KEYAUTH_SESSIONID = ""


def KeyAuthInit():
   global KEYAUTH_SESSIONID

   url = "https://keyauth.win/api/1.3/"

   params = {
      "type": "init",
      "ver": KEYAUTH_VERSION,
      "name": KEYAUTH_NAME,
      "ownerid": KEYAUTH_OWNERID
   }

   try:
      response = requests.get(url, params=params, timeout=10).json()

      if response.get("success"):
         KEYAUTH_SESSIONID = response.get("sessionid")
         return True
      else:
         print(MainColor(f"\n {red}[x]{white} KeyAuth init error: {response.get('message')}"))
         return False

   except Exception as e:
      print(MainColor(f"\n {red}[x]{white} Error conectando con KeyAuth: {e}"))
      return False



def KeyAuthRegister(username, password, license_key):
   url = "https://keyauth.win/api/1.3/"

   params = {
   "type": "register",
   "username": username,
   "pass": password,
   "key": license_key,
   "hwid": GetHWID(),
   "sessionid": KEYAUTH_SESSIONID,
   "name": KEYAUTH_NAME,
   "ownerid": KEYAUTH_OWNERID
}

   try:
      response = requests.get(url, params=params, timeout=10).json()

      if response.get("success"):
         return True, response.get("message", "Registered successfully")
      else:
         return False, response.get("message", "Invalid key or user already exists")

   except Exception as e:
      return False, f"Error conectando con KeyAuth: {e}"
  
def FormatLicenseTime(expiry):
   try:
      if expiry is None or str(expiry).strip() == "":
         return "Lifetime +10 years"

      expiry = int(expiry)
      now = int(time.time())

      seconds_left = expiry - now
      days_left = seconds_left // 86400

      if days_left >= 3650:
         return "Lifetime +10 years"

      if days_left <= 0:
         return "Expired"

      if days_left == 1:
         return "1 day left"

      return f"{days_left} days left"

   except:
      return "Lifetime +10 years"


def GetLicenseFromKeyAuthData(data):
   try:
      info = data.get("info", {})

      subscriptions = info.get("subscriptions", [])

      if len(subscriptions) > 0:
         expiry = subscriptions[0].get("expiry")
         return FormatLicenseTime(expiry)

      expiry = info.get("expiry")
      return FormatLicenseTime(expiry)

   except:
      return "Lifetime +10 years"

def KeyAuthLogin(username, password):
   url = "https://keyauth.win/api/1.3/"

   params = {
      "type": "login",
      "username": username,
      "pass": password,
      "hwid": GetHWID(),
      "sessionid": KEYAUTH_SESSIONID,
      "name": KEYAUTH_NAME,
      "ownerid": KEYAUTH_OWNERID
   }

   try:
      response = requests.get(url, params=params, timeout=10).json()

      if response.get("success"):
         license_time = GetLicenseFromKeyAuthData(response)

         user_data = {
            "username": username,
            "license": license_time
         }

         return True, response.get("message", "Logged in"), user_data

      else:
         return False, response.get("message", "Usuario o contraseña incorrectos"), None

   except Exception as e:
      return False, f"Error conectando con KeyAuth: {e}", None


def GetHWID():
   try:
      import hashlib
      import subprocess
      import getpass
      import platform

      values = []

      try:
         uuid = subprocess.check_output(
            "wmic csproduct get uuid",
            shell=True,
            stderr=subprocess.DEVNULL
         ).decode(errors="ignore").split("\n")[1].strip()
         values.append(uuid)
      except:
         pass

      try:
         bios = subprocess.check_output(
            "wmic bios get serialnumber",
            shell=True,
            stderr=subprocess.DEVNULL
         ).decode(errors="ignore").split("\n")[1].strip()
         values.append(bios)
      except:
         pass

      try:
         baseboard = subprocess.check_output(
            "wmic baseboard get serialnumber",
            shell=True,
            stderr=subprocess.DEVNULL
         ).decode(errors="ignore").split("\n")[1].strip()
         values.append(baseboard)
      except:
         pass

      values.append(getpass.getuser())
      values.append(platform.node())

      raw_hwid = "|".join(values)

      if raw_hwid.strip() == "" or len(raw_hwid) < 10:
         raw_hwid = "PARABLE-FALLBACK-HWID-" + getpass.getuser() + "-" + platform.node()

      return hashlib.sha256(raw_hwid.encode()).hexdigest()

   except:
      return "PARABLE-UNKNOWN-HWID-000000000000000000000000"

SESSION_PATH = "parable_session.json"


def Success(text):
   return GREEN + text + RESET


def Warning(text):
   return YELLOW + text + RESET


def InfoText(text):
   return GRAY + text + RESET


def BeepSuccess():
   if winsound:
      try:
         winsound.Beep(750, 100)
         winsound.Beep(950, 100)
         winsound.Beep(1200, 140)
      except:
         pass


def BeepError():
   if winsound:
      try:
         winsound.Beep(300, 180)
      except:
         pass


def LoadingLine(text, seconds=0.8):
   LoadingBar(text, seconds, 28)


def AccessGrantedAnimation(username):
   Clear()
   Title("Access Granted")
   HideCursor()
   try:
      print("")
      print(ShineLogo(999), end="")
      print(MainColor("                                           Secure Authentication System"))
      print("")
      Box("PARABLE SECURITY CHECK", [
         "Initializing secure environment...",
         "Validating encrypted session...",
         "Checking HWID fingerprint...",
         "Loading premium profile...",
         "Preparing Parable interface..."
      ])
      print("")
      checks = ["Checking credentials", "Verifying HWID", "Checking license status", "Loading user profile", "Starting Parable Tool"]
      for check in checks:
         LoadingBar(check, 0.7, 28)
         StatusOK(check)
      print("")
      print(f"{GREEN} ┌──────────────────────────────────────────────┐{RESET}")
      print(f"{GREEN} │              ACCESS GRANTED                  │{RESET}")
      print(f"{GREEN} └──────────────────────────────────────────────┘{RESET}")
      print("")
      print(RESET, end="")
      SlowPrint(f"{RESET} {RED}[{WHITE}+{RED}]{WHITE} Welcome back, {RED}{username}{RESET}", 0.025)
      BeepSuccess()
      time.sleep(1.2)
   finally:
      ShowCursor()



def SaveSession(username, license_time="Lifetime +10 years"):
   try:
      data = {
         "username": username,
         "license": license_time,
         "hwid": GetHWID(),
         "created_at": datetime.datetime.now().isoformat(),
         "expires_at": (datetime.datetime.now() + datetime.timedelta(days=7)).isoformat()
      }

      with open(SESSION_PATH, "w") as file:
         json.dump(data, file, indent=4)

      return True

   except:
      return False


def LoadSession():
   try:
      if not os.path.exists(SESSION_PATH):
         return None

      with open(SESSION_PATH, "r") as file:
         data = json.load(file)

      expires_at = datetime.datetime.fromisoformat(data.get("expires_at", "2000-01-01T00:00:00"))

      if datetime.datetime.now() > expires_at:
         os.remove(SESSION_PATH)
         return None

      if data.get("hwid") != GetHWID():
         os.remove(SESSION_PATH)
         return None

      return data

   except:
      return None


def ShowUserInfo(username, license_time="Lifetime +10 years", saved_session=False):
   Clear()
   Title("User Info")

   session_status = "Restored" if saved_session else "Active"

   print("")
   print(MainColor(f"""
 ┌──────────────────────────────────────────────┐
 │                 USER PROFILE                 │
 ├──────────────────────────────────────────────┤
 │ Username : {username.ljust(33)}│
 │ Status   : {session_status.ljust(33)}│
 │ License  : {license_time.ljust(33)}│
 │ HWID     : {"Verified".ljust(33)}│
 │ Access   : {"Premium".ljust(33)}│
 └──────────────────────────────────────────────┘
"""))

   time.sleep(1.8)


def PasswordInput(prompt="Password: "):
   print(prompt, end="", flush=True)

   password = ""

   while True:
      key = msvcrt.getwch()

      if key == "\r":
         print()
         return password

      elif key == "\b":
         if len(password) > 0:
            password = password[:-1]
            print("\b \b", end="", flush=True)

      elif key == "\x03":
         raise KeyboardInterrupt

      else:
         password += key
         print("*", end="", flush=True)


def SelectAuthOption():
   options = [("Register", "Create a new Parable account"), ("Login", "Access with your existing account"), ("Exit", "Close the application")]
   selected = 0
   while True:
      Clear()
      Title("Parable Auth")
      print("")
      print("")
      print(ShineLogo(999), end="")
      print(MainColor("                                           discord.gg/JdRaaAedut"))
      print("")
      print(MainColor(" ┌──────────────────────────────────────────────┐"))
      print(MainColor(" │              PARABLE AUTH SYSTEM             │"))
      print(MainColor(" ├──────────────────────────────────────────────┤"))
      print(MainColor(" │                                              │"))
      for i, item in enumerate(options):
         name, desc = item
         if i == selected:
            print(MainColor(f" │   {red}>{white} {name.ljust(38)} │"))
            print(MainColor(f" │     {GRAY}{desc.ljust(38)}{RESET} │"))
         else:
            print(MainColor(f" │     {name.ljust(38)} │"))
            print(MainColor(f" │     {GRAY}{desc.ljust(38)}{RESET} │"))
      print(MainColor(" │                                              │"))
      print(MainColor(" ├──────────────────────────────────────────────┤"))
      print(MainColor(" │   Use ↑ ↓ to move | ENTER to select          │"))
      print(MainColor(" │   Protected by KeyAuth + HWID verification   │"))
      print(MainColor(" └──────────────────────────────────────────────┘"))
      key = msvcrt.getwch()
      if key == "\xe0":
         arrow = msvcrt.getwch()
         if arrow == "H":
            selected = (selected - 1) % len(options)
         elif arrow == "P":
            selected = (selected + 1) % len(options)
      elif key == "\r":
         return str(selected + 1)
      elif key in ["1", "2", "3"]:
         return key


# ==========================================================
# 🔄 PARABLE AUTO UPDATER PRO - SAFE VERSION
# ==========================================================

LOCAL_VERSION = "1.0.4"

UPDATE_VERSION_URL = "https://raw.githubusercontent.com/lucioaraoz15-wq/ParableUpdate/main/version.txt"
UPDATE_CHANGELOG_URL = "https://raw.githubusercontent.com/lucioaraoz15-wq/ParableUpdate/main/changelog.txt"

# IMPORTANTE:
# Este nombre tiene que ser EXACTAMENTE igual al archivo ZIP subido a GitHub.
# Si en GitHub se llama parable_update.zip, dejalo así.
UPDATE_ZIP_URL = "https://raw.githubusercontent.com/lucioaraoz15-wq/ParableUpdate/main/parable_update.zip"

UPDATE_ZIP_NAME = "parable_update.zip"
UPDATE_TEMP_FOLDER = "parable_update_temp"

try:
   UPDATE_STATE_PATH = os.path.join(appdata_path, "update_state.json")
   BACKUP_FOLDER = os.path.join(appdata_path, "backup_before_update")
except:
   UPDATE_STATE_PATH = "update_state.json"
   BACKUP_FOLDER = "backup_before_update"


def VersionToTuple(version):
   try:
      clean = str(version).strip().replace("v", "")
      return tuple(int(part) for part in clean.split("."))
   except:
      return (0, 0, 0)


def GetOnlineText(url):
   try:
      response = requests.get(url, timeout=15)
      response.raise_for_status()
      return response.text.strip()
   except:
      return None


def SaveInstalledVersion(version):
   try:
      data = {
         "installed_version": str(version).strip(),
         "updated_at": datetime.datetime.now().isoformat()
      }

      with open(UPDATE_STATE_PATH, "w", encoding="utf-8") as file:
         json.dump(data, file, indent=4)

      return True

   except:
      return False


def GetInstalledVersion():
   try:
      if not os.path.exists(UPDATE_STATE_PATH):
         return LOCAL_VERSION

      with open(UPDATE_STATE_PATH, "r", encoding="utf-8") as file:
         data = json.load(file)

      return str(data.get("installed_version", LOCAL_VERSION)).strip()

   except:
      return LOCAL_VERSION


def CheckForUpdate():
   try:
      online_version = GetOnlineText(UPDATE_VERSION_URL)

      if not online_version:
         return False, None, None

      installed_version = GetInstalledVersion()

      if VersionToTuple(online_version) > VersionToTuple(installed_version):
         changelog = GetOnlineText(UPDATE_CHANGELOG_URL)

         if not changelog:
            changelog = "No changelog available."

         return True, online_version, changelog

      return False, online_version, None

   except:
      return False, None, None


def RemoveReadOnly(func, path, exc_info):
   try:
      os.chmod(path, 0o777)
      func(path)
   except:
      pass


def SafeRemoveFile(path):
   try:
      if os.path.exists(path):
         os.chmod(path, 0o777)
         os.remove(path)
      return True
   except:
      return False


def SafeRemoveFolder(path):
   try:
      if os.path.exists(path):
         shutil.rmtree(path, onerror=RemoveReadOnly)
      return True
   except:
      return False


def CleanUpdateTemp():
   SafeRemoveFile(UPDATE_ZIP_NAME)
   SafeRemoveFolder(UPDATE_TEMP_FOLDER)


def DownloadUpdateFile(url, filename):
   try:
      response = requests.get(url, stream=True, timeout=60)
      response.raise_for_status()

      total = int(response.headers.get("content-length", 0))
      downloaded = 0

      with open(filename, "wb") as file:
         for chunk in response.iter_content(chunk_size=8192):
            if chunk:
               file.write(chunk)
               downloaded += len(chunk)

               if total > 0:
                  percent = int((downloaded / total) * 100)
                  print(MainColor(f"\r {red}[{white}+{red}]{white} Downloading update... {percent}%"), end="", flush=True)

      print("")
      return True

   except Exception as e:
      raise Exception(f"Download failed: {e}")


def ValidateDownloadedZip(zip_path):
   if not os.path.exists(zip_path):
      raise Exception("Update package was not downloaded.")

   size = os.path.getsize(zip_path)

   if size < 100:
      raise Exception(
         f"Update package is too small ({size} bytes). "
         "Your GitHub ZIP is empty or the URL is wrong."
      )

   if not zipfile.is_zipfile(zip_path):
      preview = ""

      try:
         with open(zip_path, "r", encoding="utf-8", errors="ignore") as file:
            preview = file.read(200)
      except:
         preview = "Could not read downloaded file."

      raise Exception(
         "Downloaded file is not a valid ZIP. "
         "Check GitHub URL. Preview: " + preview[:120]
      )

   return True


def SafeExtractZip(zip_path, extract_to):
   try:
      extract_to_abs = os.path.abspath(extract_to)

      os.makedirs(extract_to_abs, exist_ok=True)

      with zipfile.ZipFile(zip_path, "r") as zip_ref:
         for member in zip_ref.namelist():
            member_path = os.path.abspath(os.path.join(extract_to_abs, member))

            if not member_path.startswith(extract_to_abs):
               raise Exception(f"Unsafe path detected in ZIP: {member}")

         zip_ref.extractall(extract_to_abs)

      return True

   except Exception as e:
      raise Exception(f"ZIP extraction failed: {e}")


def GetUpdateSourceRoot():
   """
   Permite estos dos formatos:

   Correcto:
   temp/
      Multi-Tool.py
      Program/
      Img/

   También acepta:
   temp/
      Parable-Tool/
         Multi-Tool.py
         Program/
         Img/
   """

   if os.path.exists(os.path.join(UPDATE_TEMP_FOLDER, "Multi-Tool.py")):
      return UPDATE_TEMP_FOLDER

   items = os.listdir(UPDATE_TEMP_FOLDER)

   if len(items) == 1:
      only_item = os.path.join(UPDATE_TEMP_FOLDER, items[0])

      if os.path.isdir(only_item):
         if os.path.exists(os.path.join(only_item, "Multi-Tool.py")) or os.path.exists(os.path.join(only_item, "Program")):
            return only_item

   return UPDATE_TEMP_FOLDER


def ValidateUpdateStructure(source_root):
   program_path = os.path.join(source_root, "Program")
   multi_tool_path = os.path.join(source_root, "Multi-Tool.py")

   if not os.path.exists(multi_tool_path):
      raise Exception("The update ZIP does not contain Multi-Tool.py.")

   if not os.path.exists(program_path):
      raise Exception("The update ZIP does not contain Program folder.")

   config_path = os.path.join(program_path, "Config", "Config.py")

   if not os.path.exists(config_path):
      raise Exception("The update ZIP does not contain Program\\Config\\Config.py.")

   return True


def BackupCurrentFiles():
   try:
      SafeRemoveFolder(BACKUP_FOLDER)
      os.makedirs(BACKUP_FOLDER, exist_ok=True)

      ignored = {
         UPDATE_ZIP_NAME,
         UPDATE_TEMP_FOLDER,
         "backup_before_update",
         "__pycache__",
         "Program_Bad",
         "test_update.zip",
         "test_extract",
         "parable_session.json",
         "settings.json",
         "parable_profile.json",
         "update_state.json",
         "Menu.txt"
      }

      for item in os.listdir(os.getcwd()):
         if item in ignored:
            continue

         src = os.path.join(os.getcwd(), item)
         dst = os.path.join(BACKUP_FOLDER, item)

         try:
            if os.path.isdir(src):
               shutil.copytree(
                  src,
                  dst,
                  ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "backup_before_update", "parable_update_temp")
               )
            else:
               shutil.copy2(src, dst)

         except:
            pass

      return True

   except Exception as e:
      raise Exception(f"Backup failed: {e}")


def RestoreBackup():
   try:
      if not os.path.exists(BACKUP_FOLDER):
         return False

      for item in os.listdir(BACKUP_FOLDER):
         src = os.path.join(BACKUP_FOLDER, item)
         dst = os.path.join(os.getcwd(), item)

         try:
            if os.path.isdir(src):
               if os.path.exists(dst):
                  SafeRemoveFolder(dst)
               shutil.copytree(src, dst)
            else:
               shutil.copy2(src, dst)

         except:
            pass

      return True

   except:
      return False


def InstallUpdate():
   try:
      Clear()
      Title("Installing Update")

      print("")
      print(ShineLogo(999), end="")
      print(MainColor("                                           Parable Safe Update System"))
      print("")

      print(f"{RED} ┌──────────────────────────────────────────────┐{RESET}")
      print(f"{RED} │{WHITE}              INSTALLING UPDATE         {RED}│{RESET}")
      print(f"{RED} └──────────────────────────────────────────────┘{RESET}")
      print("")

      CleanUpdateTemp()

      LoadingLine("Preparing update", 0.6)

      print(MainColor(f" {red}[{white}+{red}]{white} Downloading update package..."))
      DownloadUpdateFile(UPDATE_ZIP_URL, UPDATE_ZIP_NAME)

      LoadingLine("Validating update package", 0.6)
      ValidateDownloadedZip(UPDATE_ZIP_NAME)

      LoadingLine("Creating backup", 0.7)
      BackupCurrentFiles()

      LoadingLine("Extracting update", 0.7)
      SafeRemoveFolder(UPDATE_TEMP_FOLDER)
      os.makedirs(UPDATE_TEMP_FOLDER, exist_ok=True)
      SafeExtractZip(UPDATE_ZIP_NAME, UPDATE_TEMP_FOLDER)

      source_root = GetUpdateSourceRoot()

      LoadingLine("Checking update structure", 0.6)
      ValidateUpdateStructure(source_root)

      LoadingLine("Installing files", 0.8)

      ignored = {
         "parable_session.json",
         "settings.json",
         "parable_profile.json",
         "update_state.json",
         "Menu.txt",
         "__pycache__",
         "backup_before_update",
         "parable_update_temp",
         "test_extract",
         "test_update.zip"
      }

      for item in os.listdir(source_root):
         if item in ignored:
            continue

         src = os.path.join(source_root, item)
         dst = os.path.join(os.getcwd(), item)

         try:
            if os.path.isdir(src):
               if os.path.exists(dst):
                  SafeRemoveFolder(dst)
               shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            else:
               shutil.copy2(src, dst)

         except Exception as e:
            raise Exception(f"Error updating {item}: {e}")

      online_version = GetOnlineText(UPDATE_VERSION_URL)

      if online_version:
         SaveInstalledVersion(online_version)

      CleanUpdateTemp()

      print("")
      print(f"{GREEN} ┌──────────────────────────────────────────────┐{RESET}")
      print(f"{GREEN} │              UPDATE INSTALLED                │{RESET}")
      print(f"{GREEN} └──────────────────────────────────────────────┘{RESET}")
      print("")

      print(MainColor(f" {red}[{white}+{red}]{white} Update installed successfully."))
      print(MainColor(f" {red}[!]{white} Restarting Parable Tool..."))

      BeepSuccess()
      time.sleep(2)
      RestartProgram()

   except Exception as e:
      BeepError()

      print("")
      print(f"{RED} ┌──────────────────────────────────────────────┐{RESET}")
      print(f"{RED} │{WHITE}              UPDATE FAILED             {RED}│{RESET}")
      print(f"{RED} └──────────────────────────────────────────────┘{RESET}")
      print("")

      print(MainColor(f" {red}[x]{white} Update error: {e}"))
      print(MainColor(f" {red}[!]{white} Trying to restore backup..."))

      restored = RestoreBackup()
      CleanUpdateTemp()

      if restored:
         print(MainColor(f" {red}[{white}+{red}]{white} Backup restored successfully."))
      else:
         print(MainColor(f" {red}[x]{white} Could not restore backup."))

      input(MainColor(f"\n {red}[!]{white} Press Enter to continue... {reset}"))


def RestartProgram():
   try:
      python = sys.executable
      os.execl(python, python, *sys.argv)
   except:
      subprocess.Popen([sys.executable] + sys.argv)
      sys.exit()


def ShowUpdatePanel(manual=True):
   Clear()
   Title("Parable Update")

   print("")
   try:
      print(ShineLogo(999), end="")
   except:
      pass

   print(f"{RED}                                           Professional Update System{RESET}")
   print("")

   update_available, online_version, changelog = CheckForUpdate()

   installed_version = GetInstalledVersion()
   latest = online_version if online_version else "Unknown"
   status = "UPDATE AVAILABLE" if update_available else "UP TO DATE"

   print(f"{RED} ┌────────────────────────────────────────────────────────┐{RESET}")
   print(f"{RED} │{WHITE}                 PARABLE AUTO UPDATER                 {RED}│{RESET}")
   print(f"{RED} ├────────────────────────────────────────────────────────┤{RESET}")
   print(f"{RED} │{WHITE} Local Version    : {LOCAL_VERSION.ljust(34)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Installed Version: {installed_version.ljust(34)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Latest Version   : {str(latest).ljust(34)}{RED}│{RESET}")
   print(f"{RED} │{WHITE} Status           : {(YELLOW if update_available else GREEN)}{status.ljust(34)}{RED}│{RESET}")
   print(f"{RED} └────────────────────────────────────────────────────────┘{RESET}")
   print("")

   print(f"{RED} [{WHITE}+{RED}]{WHITE} Changelog:")
   print("")

   if changelog:
      for line in str(changelog).splitlines()[:12]:
         print(f"   {GRAY}{line}{RESET}")
   else:
      print(f"   {GRAY}No changelog available or update server offline.{RESET}")

   print("")

   if not update_available:
      if manual:
         input(f"{RED} [{WHITE}!{RED}]{WHITE} Press Enter to return... {RESET}")
      return True

   print(f"{RED} ┌────────────────────────────────────────────────────────┐{RESET}")
   print(f"{RED} │{WHITE} [1] Install update now                          {RED}│{RESET}")
   print(f"{RED} │{WHITE} [2] Exit                                        {RED}│{RESET}")
   print(f"{RED} └────────────────────────────────────────────────────────┘{RESET}")
   print("")

   choice = input(f"{RED} [{WHITE}?{RED}]{WHITE} Select option: {RESET}").strip()

   if choice == "1":
      InstallUpdate()
      return False

   ExitAnimation()
   return False


def RunUpdateCheckerPro():
   try:
      update_available, online_version, changelog = CheckForUpdate()

      if not update_available:
         return True

      while True:
         Clear()
         Title("Parable Update Required")

         print("")
         print(ShineLogo(999), end="")
         print(f"{RED}                                           Parable Update System{RESET}")
         print("")

         installed_version = GetInstalledVersion()

         print(f"{RED} ┌──────────────────────────────────────────────┐{RESET}")
         print(f"{RED} │{WHITE}              UPDATE REQUIRED           {RED}│{RESET}")
         print(f"{RED} ├──────────────────────────────────────────────┤{RESET}")
         print(f"{RED} │{WHITE} Local Version    : {LOCAL_VERSION.ljust(24)}{RED}│{RESET}")
         print(f"{RED} │{WHITE} Installed Version: {installed_version.ljust(24)}{RED}│{RESET}")
         print(f"{RED} │{WHITE} New Version      : {str(online_version).ljust(24)}{RED}│{RESET}")
         print(f"{RED} └──────────────────────────────────────────────┘{RESET}")
         print("")

         print(f" {RED}[{WHITE}!{RED}]{WHITE} Hay una nueva actualización disponible.{RESET}")
         print(f" {RED}[{WHITE}!{RED}]{WHITE} Tenés que actualizar para poder usar Parable Tool.{RESET}")
         print(f" {RED}[{WHITE}!{RED}]{WHITE} Esta versión vieja está bloqueada.{RESET}")
         print("")

         print(f" {RED}[{WHITE}+{RED}]{WHITE} Changelog:{RESET}")
         print("")

         if changelog:
            for line in str(changelog).splitlines()[:10]:
               print(f"   {GRAY}{line}{RESET}")
         else:
            print(f"   {GRAY}No changelog available.{RESET}")

         print("")
         print(f"{RED} ┌──────────────────────────────────────────────┐{RESET}")
         print(f"{RED} │{WHITE} [1] Update now                         {RED}│{RESET}")
         print(f"{RED} │{WHITE} [2] Exit                               {RED}│{RESET}")
         print(f"{RED} └──────────────────────────────────────────────┘{RESET}")
         print("")

         choice = input(f" {RED}[{WHITE}?{RED}]{WHITE} Select option: {RESET}").strip()

         if choice == "1":
            InstallUpdate()
            return False

         elif choice == "2":
            ExitAnimation()
            return False

         else:
            BeepError()
            print(f"\n {RED}[x]{WHITE} Invalid option.{RESET}")
            time.sleep(1)

   except Exception as e:
      print(f"\n {RED}[x]{WHITE} Error checking update: {e}{RESET}")
      print(f" {RED}[!]{WHITE} No se pudo verificar la actualización. El programa se cerrará.{RESET}")
      input(f"\n {RED}[!]{WHITE} Press Enter to exit... {RESET}")
      exit()

# ==========================================================
# 👋 ANIMACIÓN DE CIERRE
# ==========================================================

def ExitAnimation():
   Clear()
   Title("Closing Parable Tool")

   try:
      HideCursor()
   except:
      pass

   try:
      print("")
      try:
         print(ShineLogo(999), end="")
      except:
         pass

      print(f"{RED}                                           Closing Session{RESET}")
      print("")

      steps = [
         "Saving settings",
         "Closing secure session",
         "Cleaning temporary cache",
         "Stopping services",
         "Goodbye"
      ]

      for step in steps:
         LoadingBar(step, 0.45, 26)
         print(f" {RED}[{WHITE}+{RED}]{WHITE} {step} {GREEN}OK{RESET}")

      print("")
      print(f"{RED} ┌──────────────────────────────────────────────┐{RESET}")
      print(f"{RED} │{WHITE}       THANK YOU FOR USING PARABLE      {RED}│{RESET}")
      print(f"{RED} └──────────────────────────────────────────────┘{RESET}")
      print("")
      SlowPrint(f"{RESET} {RED}[{WHITE}+{RED}]{WHITE} See you soon.{RESET}", 0.025)
      time.sleep(1)

   finally:
      try:
         ShowCursor()
      except:
         pass

   sys.exit()


def Register():
   Clear()
   Title("Register")
   print("")
   print(ShineLogo(999), end="")
   print(MainColor("                                           Account Register Panel"))
   print("")
   Box("REGISTER", ["Create your Parable account using a valid license key.", "Your account will be linked to your current HWID.", "Keep your credentials safe."])
   print("")
   username = input(MainColor(f" {red}[{white}+{red}]{white} Username: {reset}")).strip()
   password = PasswordInput(MainColor(f" {red}[{white}+{red}]{white} Password: {reset}")).strip()
   license_key = input(MainColor(f" {red}[{white}+{red}]{white} Key: {reset}")).strip()
   if username == "" or password == "" or license_key == "":
      BeepError()
      print("")
      StatusError("Complete all fields.")
      PressToContinue()
      return
   print("")
   LoadingBar("Connecting with KeyAuth", 0.8)
   LoadingBar("Validating license key", 0.8)
   LoadingBar("Creating account", 0.8)
   success, message = KeyAuthRegister(username, password, license_key)
   print("")
   if success:
      BeepSuccess()
      StatusOK("Account registered successfully")
   else:
      BeepError()
      StatusError(message)
   PressToContinue()



def Login():
   Clear()
   Title("Login")
   print("")
   print(ShineLogo(999), end="")
   print(MainColor("                                           Secure Login Panel"))
   print("")
   Box("LOGIN", ["Enter your credentials to access Parable Tool.", "Your device will be verified with HWID protection.", "Make sure your username and password are correct."])
   print("")
   username = input(MainColor(f" {red}[{white}+{red}]{white} Username: {reset}")).strip()
   password = PasswordInput(MainColor(f" {red}[{white}+{red}]{white} Password: {reset}")).strip()
   if username == "" or password == "":
      BeepError()
      StatusError("Complete all fields.")
      PressToContinue()
      return False
   print("")
   LoadingBar("Connecting with KeyAuth", 0.8)
   LoadingBar("Checking credentials", 0.8)
   LoadingBar("Verifying HWID", 0.8)
   success, message, user_data = KeyAuthLogin(username, password)
   if success:
      print("")
      StatusOK("Login successful")
      SaveProfile(username, user_data.get("license", "Lifetime +10 years"), "Active")
      remember = input(MainColor(f"\n {red}[{white}?{red}]{white} Remember this device? [Y/N]: {reset}")).strip().lower()
      if remember == "y":
         SaveSession(username, user_data.get("license", "Lifetime +10 years"))
         StatusOK("Session saved for 7 days")
      time.sleep(0.7)
      AccessGrantedAnimation(username)
      ShowUserInfo(username, user_data.get("license", "Lifetime +10 years"))
      return True
   else:
      BeepError()
      print("")
      StatusError(message)
      PressToContinue()
      return False


def LoadingText(text, seconds=1.0):
   frames = ["|", "/", "-", "\\"]
   start = time.time()
   index = 0

   while time.time() - start < seconds:
      print(MainColor(f"\r {red}[{white}{frames[index % len(frames)]}{red}]{white} {text}"), end="", flush=True)
      index += 1
      time.sleep(0.08)

   print("\r" + " " * 70 + "\r", end="")


def AuthIntro():
   shine_pos = -6
   logo_width = len(PARABLE_LOGO[0])

   intro_lines = [
      "",
      "                 Initializing Parable Auth...",
      "                 Checking secure session...",
      "                 Loading authentication panel..."
   ]

   for i in range(45):
      Clear()
      Title("Parable Auth")

      print("")
      print("")
      print(ShineLogo(shine_pos), end="")
      print(MainColor("                                           discord.gg/JdRaaAedut"))
      print("")

      visible = min(len(intro_lines), i // 10)

      for line in intro_lines[:visible]:
         print(MainColor(ReThemeText(line)))

      shine_pos += 1

      if shine_pos > logo_width + 6:
         shine_pos = -6

      time.sleep(0.035)


def GetAuthLines():
   return [
      "┌──────────────────────────────────────────────┐",
      "│                                              │",
      "│              PARABLE AUTH SYSTEM             │",
      "│                                              │",
      "├──────────────────────────────────────────────┤",
      "│                                              │",
      "│   [1] Register                               │",
      "│   [2] Login                                  │",
      "│   [3] Exit                                   │",
      "│                                              │",
      "├──────────────────────────────────────────────┤",
      "│                                              │",
      "│   Secure access connected with KeyAuth       │",
      "│   Protected by HWID verification             │",
      "│                                              │",
      "└──────────────────────────────────────────────┘"
   ]


def PrintAuthMenuAnimated():
   lines = GetAuthLines()

   for i in range(len(lines) + 1):
      Clear()
      Title("Parable Auth")

      print("")
      print("")
      print(ShineLogo(999), end="")
      print(MainColor("                                           discord.gg/JdRaaAedut"))
      print("")

      for line in lines[:i]:
         print(MainColor(" " + line))

      time.sleep(0.045)


def PrintAuthMenuStatic():
   Clear()
   Title("Parable Auth")
   
   print(ShineLogo(999), end="")
   print(MainColor("                                           discord.gg/JdRaaAedut"))
   

   for line in GetAuthLines():
      print(MainColor(" " + line))


def AuthMenu():
   session = LoadSession()

   if session:
      username = session.get("username", "User")
      SaveProfile(username, session.get("license", "Lifetime +10 years"), "Restored")

      Clear()
      Title("Session Restored")

      print("")
      print(ShineLogo(999), end="")
      print(MainColor("                                           Secure Authentication System"))
      print("")

      LoadingLine("Checking saved session", 0.8)
      LoadingLine("Verifying HWID", 0.8)
      LoadingLine("Restoring access", 0.8)

      AccessGrantedAnimation(username)
      ShowUserInfo(username, saved_session=True)
      return True

   while True:
      choice = SelectAuthOption()

      if choice == "1":
         PageTransition("Opening Register")
         Register()

      elif choice == "2":
         PageTransition("Opening Login")

         if Login():
            return True

      elif choice == "3":
         ExitAnimation()

      else:
         BeepError()
         print(MainColor(f"\n {red}[x]{white} Invalid option."))
         time.sleep(1)


def Menu():
   popup_version = ""

   try:
      with open(menu_path, "r") as file:
         menu_number = file.read().strip()

      menu_mapping = {"1": menu1, "2": menu2, "3": menu3}
      menu = menu_mapping.get(menu_number, menu1)

   except:
      menu = menu1
      menu_number = "1"

   banner = BuildBanner(menu, 999)

   return banner, menu_number, menu


EnableAnsi()
SetProfessionalConsole(150, 42)

if not KeyAuthInit():
   input(MainColor(f"\n {red}[!]{white} Press Enter to exit..."))
   exit()

AuthMenu()

if not RunUpdateCheckerPro():
   exit()

while True:
   try:
      Clear()

      banner, menu_number, menu = Menu()

      choice = AnimateLogo(menu, menu_number)

      if choice in ['N', 'n', 'NEXT', 'Next', 'next']:
         menu_number = {"1": "2", "2": "3", "3": "1"}.get(menu_number, "1")
         with open(menu_path, "w") as file:
            file.write(menu_number)
         continue

      elif choice in ['B', 'b', 'BACK', 'Back', 'back']:
         menu_number = {"2": "1", "3": "2"}.get(menu_number, "1")
         with open(menu_path, "w") as file:
            file.write(menu_number)
         continue

      elif choice in ['I', 'i', 'INFO', 'Info', 'info']:
         StartProgram(f"{option_info}.py")
         continue

      elif choice in ['S', 's', 'SITE', 'Site', 'site']:
         StartProgram(f"{option_site}.py")
         continue

      elif choice in ['P', 'p', 'PROFILE', 'Profile', 'profile']:
         ShowProfilePanel()
         continue

      elif choice in ['T', 't', 'THEME', 'Theme', 'theme']:
         ThemePanel()
         continue

      elif choice in ['U', 'u', 'UPDATE', 'Update', 'update']:
         ShowUpdatePanel()
         continue

      elif choice in ['X', 'x', 'EXIT', 'Exit', 'exit', 'Q', 'q']:
         ExitAnimation()

      elif choice == '30':
         if os_name == "Linux":
            print(f"\n{BEFORE + current_time_hour() + AFTER} {INFO} The builder virus is only compatible with Windows, under Linux it can encounter big problems.")
            messagebox.showinfo(f"RedTiger {version_tool} - Virus Builder", "The builder virus is only compatible with Windows, under Linux it can encounter big problems.")

         print(f"\n{BEFORE + current_time_hour() + AFTER} {INFO} It is important to disable your antivirus (Real-time Protection) before building, so that no files are deleted.")
         messagebox.showinfo(f"RedTiger {version_tool} - Virus Builder", "It is important to disable your antivirus (Real-time Protection) before building, so that no files are deleted.")
         try:
            zip_file_path = os.path.join(tool_path, "Program", "FileDetectedByAntivirus", "Password(redtiger).zip")
            file_path = os.path.join(tool_path, "Program", "FileDetectedByAntivirus", "VirusBuilderOptions.py")
            output = os.path.join(tool_path, "Program", "FileDetectedByAntivirus")
            if not os.path.exists(file_path):
               if os.path.exists(zip_file_path):
                  print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Decompression of the encrypted file: {white}Program\\FileDetectedByAntivirus\\Password(redtiger).zip")
                  with pyzipper.AESZipFile(zip_file_path) as zf:
                     zf.pwd = b'redtiger'
                     zf.extractall(output)
                  time.sleep(3)
               else:
                  print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Files are missing, please reinstall the tool.")
         except Exception as e:
            Error(e)

      options = {
         '01': option_01, '02': option_02, '03': option_03, '04': option_04,
         '05': option_05, '06': option_06, '07': option_07, '08': option_08,
         '09': option_09, '10': option_10, '11': option_11, '12': option_12,
         '13': option_13, '14': option_14, '15': option_15, '16': option_16,
         '17': option_17, '18': option_18, '19': option_19, '20': option_20,
         '21': option_21, '22': option_22, '23': option_23, '24': option_24,
         '25': option_25, '26': option_26, '27': option_27, '28': option_28,
         '29': option_29, '30': option_30, '31': option_31, '32': option_32,
         '33': option_33, '34': option_34, '35': option_35, '36': option_36,
         '37': option_37, '38': option_38, '39': option_39, '40': option_40,
         '41': option_41, '42': option_42, '43': option_43, '44': option_44,
         '45': option_45, '46': option_46, '47': option_47, '48': option_48,
         '49': option_49, '50': option_50, '51': option_51, '52': option_52,
         '53': option_53, '54': option_54, '55': option_55, '56': option_56,
         '57': option_57, '58': option_58, '59': option_59, '60': option_60,
         '61': option_61, '62': option_62, '63': option_63, '64': option_64,
         '65': option_65, '66': option_66, '67': option_67, '68': option_68,
         '69': option_69, '70': option_70, '71': option_71, '72': option_72,
         '73': option_73, '74': option_74, '75': option_75, '76': option_76,
         '77': option_77, '78': option_78, '79': option_79
      }




      if choice in options:
         PageTransition(f"Opening Option {choice}")
         LoadingBar(f"Starting {options[choice]}", 0.7)
         StartProgram(f"{options[choice]}.py")
      elif '0' + choice in options:
         fixed_choice = '0' + choice
         PageTransition(f"Opening Option {fixed_choice}")
         LoadingBar(f"Starting {options[fixed_choice]}", 0.7)
         StartProgram(f"{options[fixed_choice]}.py")
      else:
         BeepError()
         LoadingBar("Invalid option", 0.4)
         ErrorChoiceStart()

   except KeyboardInterrupt:
      ExitAnimation()
   except Exception as e:
      Error(str(e))
