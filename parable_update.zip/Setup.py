try:
    import sys
    import os
    import subprocess
    import platform
    import time

    # ==========================================================
    # PARABLE TOOL SETUP
    # ==========================================================

    MAIN_FILE = "Multi-Tool.py"

    REQUIRED_PACKAGES = [
        "requests",
        "pyzipper",
        "customtkinter",
        "cryptography",
        "discord.py",
        "colorama",
        "phonenumbers",
        "instaloader",
        "pillow",
        "psutil",
        "python-dotenv",
        "aiohttp",
        "beautifulsoup4",
        "lxml",
        "pystyle",
        "pycryptodome",
        "qrcode",
        "pyperclip",
        "urllib3",
        "certifi",
        "idna",
        "charset-normalizer",
        "typing_extensions",
        "packaging",
        "setuptools",
        "wheel"
    ]

    WINDOWS_ONLY_PACKAGES = [
        "pywin32",
        "wmi",
        "winshell"
    ]

    LINUX_ONLY_PACKAGES = []

    def clear():
        os.system("cls" if os.name == "nt" else "clear")

    def pause():
        input("\nPresiona ENTER para continuar...")

    def run_command(command):
        try:
            return subprocess.call(command)
        except Exception as e:
            print(f"❌ Error ejecutando comando: {e}")
            return 1

    def install_package(package):
        try:
            print(f"\n[+] Instalando {package}...")
            subprocess.check_call([
                sys.executable,
                "-m",
                "pip",
                "install",
                package,
                "--upgrade"
            ])
            print(f"[✓] {package} instalado correctamente.")
        except subprocess.CalledProcessError:
            print(f"[x] Error instalando: {package}")
        except Exception as e:
            print(f"[x] Error instalando {package}: {e}")

    def upgrade_pip():
        print("\n[+] Actualizando pip, setuptools y wheel...\n")

        packages = [
            "pip",
            "setuptools",
            "wheel"
        ]

        for package in packages:
            subprocess.call([
                sys.executable,
                "-m",
                "pip",
                "install",
                "--upgrade",
                package
            ])

    def install_requirements_txt():
        if os.path.exists("requirements.txt"):
            print("\n[+] Instalando requirements.txt...\n")

            subprocess.call([
                sys.executable,
                "-m",
                "pip",
                "install",
                "-r",
                "requirements.txt",
                "--upgrade"
            ])
        else:
            print("\n[!] No se encontró requirements.txt, instalando paquetes base...")

    def install_all_packages():
        packages = REQUIRED_PACKAGES.copy()

        if sys.platform.startswith("win"):
            packages.extend(WINDOWS_ONLY_PACKAGES)

        elif sys.platform.startswith("linux"):
            packages.extend(LINUX_ONLY_PACKAGES)

        print("\n[+] Instalando paquetes necesarios...\n")

        for package in packages:
            install_package(package)

    def OpenSites():
        try:
            import webbrowser

            try:
                from Program.Config.Config import telegram, gunslol

                if telegram:
                    webbrowser.open(f"https://{telegram}")

                if gunslol:
                    webbrowser.open(f"https://{gunslol}")

            except:
                pass

        except:
            pass

    def check_python_version():
        major = sys.version_info.major
        minor = sys.version_info.minor

        print(f"[+] Python detectado: {major}.{minor}.{sys.version_info.micro}")

        if major < 3:
            print("[x] Necesitás Python 3.")
            pause()
            sys.exit()

        if minor < 10:
            print("[!] Recomendado usar Python 3.10 o superior.")

    def start_tool():
        if not os.path.exists(MAIN_FILE):
            print(f"\n[x] No se encontró {MAIN_FILE}")
            print("[!] Asegurate de que este Setup.py esté en la misma carpeta que ParableTool.py")
            pause()
            return

        print(f"\n[+] Iniciando {MAIN_FILE}...\n")
        time.sleep(1)

        try:
            subprocess.call([
                sys.executable,
                MAIN_FILE
            ])
        except Exception as e:
            print(f"[x] Error iniciando {MAIN_FILE}: {e}")
            pause()

    def main():
        clear()

        print("""
██████╗  █████╗ ██████╗  █████╗ ██████╗ ██╗     ███████╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔══██╗██║     ██╔════╝
██████╔╝███████║██████╔╝███████║██████╔╝██║     █████╗  
██╔═══╝ ██╔══██║██╔══██╗██╔══██║██╔══██╗██║     ██╔══╝  
██║     ██║  ██║██║  ██║██║  ██║██████╔╝███████╗███████╗
╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝
""")

        print("Installing the python modules required for the Parable Tool:\n")

        print(f"[+] Sistema: {platform.system()} {platform.release()}")
        print(f"[+] Ejecutable Python: {sys.executable}")

        check_python_version()
        upgrade_pip()
        install_requirements_txt()
        install_all_packages()

        print("\n[✓] Instalación terminada.")

        OpenSites()
        start_tool()

    if __name__ == "__main__":
        main()

except Exception as e:
    print(f"\n[x] Error general: {e}")
    input("\nPresiona ENTER para salir...")